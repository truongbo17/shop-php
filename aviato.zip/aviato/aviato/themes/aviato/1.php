<section class="products section bg-gray" style="padding-top: 0px;">
	<div class="container">
		<div class="row">
			<div class="title text-center">
				<h2>Sản phẩm theo xu hướng</h2>
			</div>
		</div>
		<div class="row">
			<?php
			//lặp 4 lần ngẫu nhiên
			//substr xóa 3 kí tự ../ để tránh lỗi ảnh
			for ($i = 0; $i < 4; $i++) {
				$product_id = $trendingProduct[$i]['id'];
				$sql = "SELECT * FROM galery_product WHERE product_id = $product_id";
				$resultGaleryProduct = executeResult($sql, true);
				if ($resultGaleryProduct == null) {
					$resultGaleryProduct['thumbnail'] = 'https://mvsccs.com/public/uploads/all/hq1rH.';
				}

				echo '
				<div class="col-md-3">
				<div class="product-item">
					<div class="product-thumb">';
				if ($trendingProduct[$i]['discount'] > 0) {
					echo '<span class="bage">Sale '.$trendingProduct[$i]['discount'].' %</span>';
				}
				echo '<img class="img-responsive" src="' . substr($resultGaleryProduct['thumbnail'], 3) . '" alt="product-img" style="height: 360px;"/>
						<div class="preview-meta">
							<ul>
								<li>
									<span data-toggle="modal" data-target="#product-modal">
										<i class="tf-ion-ios-search-strong"></i>
									</span>
								</li>
								<li>
									<a href="#!"><i class="tf-ion-ios-heart"></i></a>
								</li>
								<li>
									<a href="#!"><i class="tf-ion-android-cart"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="product-content">
						<h4><a href="product-single.html">' . $trendingProduct[$i]['title'] . '</a></h4>
						<p class="price">' . number_format($trendingProduct[$i]['price']) . ' VNĐ</p>
					</div>
				</div>
			</div>';
			}
			?>
		</div>

		<div class="row">
			<div class="title text-center">
				<h2>Thời trang nam</h2>
			</div>
		</div>
		<!-- category -->
		<div class="row">
			<?php
			//lặp 4 lần ngẫu nhiên
			//substr xóa 3 kí tự ../ để tránh lỗi ảnh
			for ($i = 0; $i < 8; $i++) {
				$product_id = $trendingProductNam[$i]['id'];
				$sql = "SELECT * FROM galery_product WHERE product_id = $product_id";
				$resultGaleryProduct = executeResult($sql, true);
				if ($resultGaleryProduct == null) {
					$resultGaleryProduct['thumbnail'] = 'https://mvsccs.com/public/uploads/all/hq1rH.';
				}

				echo '
				<div class="col-md-3">
				<div class="product-item">
					<div class="product-thumb">';
				if ($trendingProductNam[$i]['discount'] > 0) {
					echo '<span class="bage">Sale</span>';
				}
				echo '<img class="img-responsive" src="' . substr($resultGaleryProduct['thumbnail'], 3) . '" alt="product-img" style="height: 360px;"/>
						<div class="preview-meta">
							<ul>
								<li>
									<span data-toggle="modal" data-target="#product-modal">
										<i class="tf-ion-ios-search-strong"></i>
									</span>
								</li>
								<li>
									<a href="#!"><i class="tf-ion-ios-heart"></i></a>
								</li>
								<li>
									<a href="#!"><i class="tf-ion-android-cart"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="product-content">
						<h4><a href="product-single.html">' . $trendingProductNam[$i]['title'] . '</a></h4>
						<p class="price">' . number_format($trendingProductNam[$i]['price']) . ' VNĐ</p>
					</div>
				</div>
			</div>';
			}
			?>
		</div>
		<!-- end category -->

		<div class="row">
			<div class="title text-center">
				<h2>Thời trang nữ</h2>
			</div>
		</div>
		<!-- category -->
		<div class="row">
			<?php
			//lặp 4 lần ngẫu nhiên
			//substr xóa 3 kí tự ../ để tránh lỗi ảnh
			for ($i = 0; $i < 8; $i++) {
				$product_id = $trendingProductNu[$i]['id'];
				$sql = "SELECT * FROM galery_product WHERE product_id = $product_id";
				$resultGaleryProduct = executeResult($sql, true);
				if ($resultGaleryProduct == null) {
					$resultGaleryProduct['thumbnail'] = 'https://mvsccs.com/public/uploads/all/hq1rH.';
				}

				echo '
				<div class="col-md-3">
				<div class="product-item">
					<div class="product-thumb">';
				if ($trendingProductNu[$i]['discount'] > 0) {
					echo '<span class="bage">Sale</span>';
				}
				echo '<img class="img-responsive" src="' . substr($resultGaleryProduct['thumbnail'], 3) . '" alt="product-img" style="height: 360px;"/>
						<div class="preview-meta">
							<ul>
								<li>
									<span data-toggle="modal" data-target="#product-modal">
										<i class="tf-ion-ios-search-strong"></i>
									</span>
								</li>
								<li>
									<a href="#!"><i class="tf-ion-ios-heart"></i></a>
								</li>
								<li>
									<a href="#!"><i class="tf-ion-android-cart"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="product-content">
						<h4><a href="product-single.html">' . $trendingProductNu[$i]['title'] . '</a></h4>
						<p class="price">' . number_format($trendingProductNu[$i]['price']) . ' VNĐ</p>
					</div>
				</div>
			</div>';
			}
			?>
		</div>
		<!-- end category -->

		<!-- Modal -->
		<div class="modal product-modal fade" id="product-modal">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<i class="tf-ion-close"></i>
			</button>
			<div class="modal-dialog " role="document">
				<div class="modal-content">
					<div class="modal-body">
						<div class="row">
							<div class="col-md-8 col-sm-6 col-xs-12">
								<div class="modal-image">
									<img class="img-responsive" src="images/shop/products/modal-product.jpg" alt="product-img" />
								</div>
							</div>
							<div class="col-md-4 col-sm-6 col-xs-12">
								<div class="product-short-details">
									<h2 class="product-title">GM Pendant, Basalt Grey</h2>
									<p class="product-price">$200</p>
									<p class="product-short-description">
										Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem iusto nihil cum. Illo laborum numquam rem aut officia dicta cumque.
									</p>
									<a href="cart.html" class="btn btn-main">Add To Cart</a>
									<a href="product-single.html" class="btn btn-transparent">View Product Details</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!-- /.modal -->
	</div>
</section>


<div class="container-fuld">
	<div class="row" style="width:100%">
		<div class="col-md-7">
			<div id="myCarousel" class="carousel slide" data-ride="carousel" style="height:300px">
				<!-- Indicators -->
				<ol class="carousel-indicators">
					<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					<li data-target="#myCarousel" data-slide-to="1"></li>
					<li data-target="#myCarousel" data-slide-to="2"></li>
				</ol>

				<!-- Wrapper for slides -->
				<div class="carousel-inner" style="height:300px">
					<div class="item active">
						<img src="https://nhakhoachoban.vn/wp-content/uploads/2020/05/happy-smile-khai-truong-co-so-moi-giam-gia-20-tat-ca-cac-dich-vu-3.png" alt="Los Angeles" style="width:100%;">
					</div>

					<div class="item">
						<img src="https://www.wheystore.vn/upload/news_optimize/main/upl_3_ng__y_v__ng__t__ng_b___ng_khai_tr____ng_1595910155_image_1595910155.jpg" alt="Chicago" style="width:100%;">
					</div>

					<div class="item">
						<img src="https://ae01.alicdn.com/kf/H7697b5396fad446c80d3e33f361010035.jpg" alt="New york" style="width:100%;">
					</div>
				</div>

				<!-- Left and right controls -->
				<a class="left carousel-control" href="#myCarousel" data-slide="prev">
					<span class="tf-ion-android-arrow-back"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="right carousel-control" href="#myCarousel" data-slide="next">
					<span class="tf-ion-android-arrow-forward"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
		<div class="col-md-5">
			<div class="row">
				<div class="col-md-6">
					<div class="category-box" style="margin-bottom:0px;min-height:150px">
						<a href="#!">
							<img src="images/shop/category/category-1.jpg" alt="" />
							<div class="content">
								<h3>Thời trang nam</h3>
								<p>Tất cả các mẫu quần áo mới nhất</p>
							</div>
						</a>
					</div>
					<div class="category-box" style="margin-bottom:20px;min-height:150px">
						<a href="#!">
							<img src="images/shop/category/category-2.jpg" alt="" />
							<div class="content">
								<h3>Thời trang nữ</h3>
								<p>Xuân Hạ Thu Đông </p>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-6">
					<div class="category-box category-box-2" style="margin-bottom:20px;min-height:300px">
						<a href="#!">
							<img src="images/shop/category/category-3.jpg" alt="" />
							<div class="content">
								<h3>Thời trang</h3>
								<p>MẶC LÀ ĐẸP ! Thế nhé =))</p>
							</div>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>